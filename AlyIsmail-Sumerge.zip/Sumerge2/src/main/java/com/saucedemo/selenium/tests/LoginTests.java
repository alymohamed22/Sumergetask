package com.saucedemo.selenium.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.saucedemo.selenium.elements.LoginPageWebElement;
import com.saucedemo.selenium.elements.ProductsPageWebElement;

public class LoginTests {
    private WebDriver driver;
    private LoginPageWebElement loginPage;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPageWebElement(driver);
    }

    @Test(priority = 1, description = "test login with valid credentials")
    public void testLoginWithValidCredentials() throws InterruptedException {
        loginPage.login(0, "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"),
                          "User is not redirected to the products page.");

        ProductsPageWebElement productPage = new ProductsPageWebElement(driver);
        productPage.logout();
    }

    @Test(priority = 2, description = "test login with invalid credentials")
    public void testLoginWithInvalidCredentials() {
        loginPage.login(0, "wrong_password");
        String errorMessage = loginPage.getErrorMessage();
        Assert.assertTrue(errorMessage.contains("Epic sadface"), "Error message"
                          + "not displayed for invalid login.");
        loginPage.getUsernameTextBoxWebElement().clear();
        loginPage.getPasswordTextBoxWebElement().clear();
    }

    @AfterClass
    public void quit() {
        driver.quit();
    }
}
