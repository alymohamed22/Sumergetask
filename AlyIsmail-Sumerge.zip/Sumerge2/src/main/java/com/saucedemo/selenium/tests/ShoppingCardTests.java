package com.saucedemo.selenium.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.saucedemo.selenium.elements.LoginPageWebElement;
import com.saucedemo.selenium.elements.ProductsPageWebElement;
import com.saucedemo.selenium.elements.ShoppingCardPageWebElement;

public class ShoppingCardTests {
    private WebDriver driver;
    private LoginPageWebElement loginPage;
    private ProductsPageWebElement productsPage;
    private ShoppingCardPageWebElement cartPage;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPageWebElement(driver);

        // Login and navigate to products page
        loginPage.login(0, "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"),
                "User is not redirected to the products page.");
        productsPage = new ProductsPageWebElement(driver);
    }

    @Test(priority = 1, description = "Add a product to cart + verify cart update")
    public void testAddProductToCart() {
        int initialCartCount = productsPage.getCartBadgeCount();
        productsPage.addProductToCart(0);

        int updatedCartCount = productsPage.getCartBadgeCount();
        Assert.assertEquals(updatedCartCount, initialCartCount + 1,
                            "Cart badge count did not update.");

        cartPage = productsPage.navigateToCart();
        Assert.assertEquals(cartPage.countCartItems(), 1,
                            "Cart does not contain the added product.");

        String cartProductName = cartPage.getCartItemName(0);
        Assert.assertEquals(cartProductName, productsPage.getProductNames().get(0),
                "Added product does not match the product in the cart.");
    }

    @Test(priority = 2, description = "Remove product from cart and verify update")
    public void testRemoveProductFromCart() {
        if (cartPage == null) {
            cartPage = productsPage.navigateToCart();
        }

        int initialCartCount = cartPage.countCartItems();
        Assert.assertTrue(initialCartCount > 0, "Cart is empty, cannot remove item.");

        cartPage.removeCartItem(0);
        int updatedCartCount = cartPage.countCartItems();
        Assert.assertEquals(updatedCartCount, initialCartCount - 1 ,"Cart item wasn't removed.");
    }

    @Test(priority = 3, description = "Verify cart count updates correctly")
    public void testCartBadgeCountUpdates() {
        int initialCartCount = productsPage.getCartBadgeCount();

        productsPage.addProductToCart(1);
        productsPage.addProductToCart(2);
        Assert.assertEquals(productsPage.getCartBadgeCount(), initialCartCount + 2,
                "Cart badge count did not update correctly after adding products.");

        cartPage = productsPage.navigateToCart();
        cartPage.removeCartItem(0);
        Assert.assertEquals(productsPage.getCartBadgeCount(), initialCartCount + 1,
                "Cart badge count did not update correctly after removing a product.");
    }

    @AfterClass
    public void quit() {
        if (driver != null) {
            driver.quit();
        }
    }
}
