package com.saucedemo.selenium.tests;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.saucedemo.selenium.elements.LoginPageWebElement;
import com.saucedemo.selenium.elements.ProductsPageWebElement;

public class ProductsPageTests {
    private WebDriver driver;
    private LoginPageWebElement loginPage;
    private ProductsPageWebElement productsPage;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPageWebElement(driver);

        loginPage.login(0, "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"),
                "User is not redirected to the products page.");
        productsPage = new ProductsPageWebElement(driver);
    }

    @Test(priority = 1, description = "Verify all products are displayed")
    public void testAllProductsDisplayed() {
        List<String> productNames = productsPage.getProductNames();
        List<String> productPrices = productsPage.getProductPrices();

        Assert.assertFalse(productNames.isEmpty(),"product names aren't displayed.");
        Assert.assertFalse(productPrices.isEmpty(), "product prices aren't displayed.");

        System.out.println("Product Names: " + productNames);
        System.out.println("Product Prices: " + productPrices);
    }

    @Test(priority = 2, description = "Sorting by Price (Low to High)")
    public void testSortingByPriceLowToHigh() {
        productsPage.sortProducts(ProductsPageWebElement.SortOption
                                  .PRICE_LOW_TO_HIGH);

        List<String> productPrices = productsPage.getProductPrices();
        double[] numericPrices = convertPricesToNumeric(productPrices);

        for (int i = 0; i < numericPrices.length - 1; i++) {
            Assert.assertTrue(numericPrices[i] <= numericPrices[i + 1],
                    "Products are not sorted by price (low to high).");
        }
    }

    @Test(priority = 3, description = "Validate sorting functionality by Price (High to Low)")
    public void testSortingByPriceHighToLow() {
        productsPage.sortProducts(ProductsPageWebElement.SortOption.PRICE_HIGH_TO_LOW);

        List<String> productPrices = productsPage.getProductPrices();
        double[] numericPrices = convertPricesToNumeric(productPrices);

        for (int i = 0; i < numericPrices.length - 1; i++) {
            Assert.assertTrue(numericPrices[i] >= numericPrices[i + 1],
                    "Products are not sorted by price (high to low).");
        }
    }

    @AfterClass
    public void quit() {
        if (driver != null) {
            driver.quit();
        }
    }

    private double[] convertPricesToNumeric(List<String> priceStrings) {
        return priceStrings.stream()
                .mapToDouble(price -> Double.parseDouble(price.replace("$", "")))
                .toArray();
    }
}
