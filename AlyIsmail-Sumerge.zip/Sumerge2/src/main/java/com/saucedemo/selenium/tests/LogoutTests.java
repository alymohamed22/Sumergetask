package com.saucedemo.selenium.tests;

public class LogoutTests {

}
