package com.saucedemo.selenium.elements;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductsPageWebElement {
    private static final By SELECTOR__PRODUCT_LIST
        = By.className("inventory_list");
    private static final By SELECTOR__PRODUCT_ITEM
        = By.className("inventory_item");
    private static final By SELECTOR__PRODUCT_NAME
        = By.className("inventory_item_name");
    private static final By SELECTOR__PRODUCT_PRICE
        = By.className("inventory_item_price");
    private static final By SELECTOR__SORT_DROPDOWN
        = By.className("product_sort_container");
    private static final By SELECTOR__ADD_TO_CART_BUTTON
        = By.className("btn_inventory");
    private static final By SELECTOR__CART_BADGE
        = By.className("shopping_cart_badge");
    private static final By SELECTOR__CART_LINK
        = By.className("shopping_cart_link");

    private final WebDriver driver;
    private final WebElement productPageElement;

    public ProductsPageWebElement(WebDriver driver) {
        this.driver = driver;
        WebElement tempElement = null;
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            tempElement = wait.until(ExpectedConditions
                .visibilityOfElementLocated(SELECTOR__PRODUCT_LIST));

        } catch (Exception e) {
            System.out.println("Product page element not found: " + e.getMessage());
        }
        this.productPageElement = tempElement;
    }

    public List<WebElement> getProductItemsWebElement() {
        return driver.findElements(SELECTOR__PRODUCT_ITEM);
    }

    public List<String> getProductNames() {
        return getProductAttribute(SELECTOR__PRODUCT_NAME);
    }

    public List<String> getProductPrices() {
        return getProductAttribute(SELECTOR__PRODUCT_PRICE);
    }

    public void sortProducts(SortOption sortOption) {
        WebElement sortDropdown = driver.findElement(SELECTOR__SORT_DROPDOWN);
        Select dropdown = new Select(sortDropdown);
        dropdown.selectByVisibleText(sortOption.getVisibleText());
    }

    public int countProducts() {
        return getProductItemsWebElement().size();
    }

    public void addProductToCart(int productIndex) {
        WebElement productElement = getProductsWebElement(productIndex);
        productElement.findElement(SELECTOR__ADD_TO_CART_BUTTON).click();
    }

    public SingleProductPageWebElement clickOnProduct(int productIndex) {
        WebElement productElement = getProductsWebElement(productIndex);
        productElement.click();
        return new SingleProductPageWebElement(driver);
    }

    public int getCartBadgeCount() {
        try {
            WebElement badgeElement = driver.findElement(SELECTOR__CART_BADGE);
            return Integer.parseInt(badgeElement.getText().trim());
        } catch (Exception e) {
            return 0;
        }
    }

    public ShoppingCardPageWebElement navigateToCart() {
        try {
            WebElement cartLink = driver.findElement(SELECTOR__CART_LINK);
            cartLink.click();
            return new ShoppingCardPageWebElement(driver);
        } catch (Exception e) {
            throw new RuntimeException("Failed to navigate to the shopping"
                                       + "cart: " + e.getMessage());
        }
    }

    public void logout() {
        By burgerMenuButton = By.id("react-burger-menu-btn");
        WebElement menuButton = driver.findElement(burgerMenuButton);
        menuButton.click();

        By logoutButton = By.id("logout_sidebar_link");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement logoutLink
            = wait.until(ExpectedConditions.elementToBeClickable(logoutButton));

        logoutLink.click();
    }

    public enum SortOption {
        NAME_A_TO_Z("Name (A to Z)"),
        NAME_Z_TO_A("Name (Z to A)"),
        PRICE_LOW_TO_HIGH("Price (low to high)"),
        PRICE_HIGH_TO_LOW("Price (high to low)");

        private final String visibleText;

        SortOption(String visibleText) {
            this.visibleText = visibleText;
        }

        public String getVisibleText() {
            return visibleText;
        }
    }

    private WebElement getProductsWebElement(int productIndex) {
        List<WebElement> productElements = getProductItemsWebElement();
        if (productIndex >= 0 && productIndex < productElements.size()) {
            return productElements.get(productIndex);
        } else {
            throw new IndexOutOfBoundsException("Invalid product index: "
                                                + productIndex);
        }
    }

    private List<String> getProductAttribute(By attributSelector) {
        List<WebElement> productElements = getProductItemsWebElement();
        List<String> attributeValues = new ArrayList<String>();
        for (WebElement product : productElements) {
            attributeValues.add(product.findElement(attributSelector).getText());
        }
        return attributeValues;
    }
}
