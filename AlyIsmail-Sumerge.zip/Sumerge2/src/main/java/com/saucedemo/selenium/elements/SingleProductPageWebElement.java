package com.saucedemo.selenium.elements;

import org.openqa.selenium.WebDriver;

public class SingleProductPageWebElement {

    public SingleProductPageWebElement(WebDriver driver) {
        // TODO Auto-generated constructor stub
    }

}
