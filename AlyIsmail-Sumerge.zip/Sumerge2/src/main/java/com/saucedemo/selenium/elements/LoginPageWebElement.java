package com.saucedemo.selenium.elements;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPageWebElement {
    private static final By SELECTOR__LOGIN_PAGE = By.className("login_container");
    private static final By SELECTOR__USERNAME_TEXTBOX = By.id("user-name");
    private static final By SELECTOR__PASSWORD_TEXTBOX = By.id("password");
    private static final By SELECTOR__LOGIN_BUTTON = By.id("login-button");
    private static final By SELECTOR__ERRORMESSAGE
        = By.className("error-message-container");
    private static final By SELECTOR__LOGINCREDENTIALS
        = By.id("login_credentials");
    private static final By SELECTOR__LOGINPASSWORD
        = By.cssSelector("[data-test='login-password']");

    private final WebDriver driver;
    private final WebElement loginPageElement;

    public LoginPageWebElement(WebDriver driver) {
        this.driver = driver;
        WebElement tempElement = null;
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            tempElement = wait.until(ExpectedConditions
                                     .visibilityOfElementLocated
                                     (SELECTOR__LOGIN_PAGE));
        }
        catch (Exception e) {
            System.out.println("Login page element not found: " + e.getMessage());
        }
        this.loginPageElement = tempElement;
    }

    public WebElement getUsernameTextBoxWebElement() {
        return driver.findElement(SELECTOR__USERNAME_TEXTBOX);
    }

    public WebElement getPasswordTextBoxWebElement() {
        return driver.findElement(SELECTOR__PASSWORD_TEXTBOX);
    }

    public void clickLoginButton() {
        driver.findElement(SELECTOR__LOGIN_BUTTON).click();
    }

    public String getErrorMessage() {
        return driver.findElement(SELECTOR__ERRORMESSAGE).getText();
    }

    public void login(int i, String password) {
        String username = chooseUserNameToLogin(i);
        getUsernameTextBoxWebElement().sendKeys(username);
        getPasswordTextBoxWebElement().sendKeys(password);
        clickLoginButton();
    }

    protected List<String> getAcceptedUsernames() {
        // Locate the element that holding the usernames
        WebElement loginCredentials
            = driver.findElement(SELECTOR__LOGINCREDENTIALS);

        // Get the entire text content of the element
        String acceptedCredentials = loginCredentials.getText();

        // Put each value in a separate line
        String[] textLines = acceptedCredentials.split("\\r?\\n");

        // Start at index 1 to skip the header
        List<String> usernames = new ArrayList<String>();
        for (int i = 1; i < textLines.length; i++) {
            usernames.add(textLines[i]);
        }
        return usernames;
    }

    protected String chooseUserNameToLogin(int i) {
        List<String> usernames = getAcceptedUsernames();

        if (i >= 0 && i < usernames.size()) {
            return usernames.get(i);
        }
        else {
            throw new IndexOutOfBoundsException
                ("Invalid index: " + i + ". List size: " + usernames.size());
        }
    }

    protected String getPasswordValue() {
        WebElement passwordContainer = driver.findElement(SELECTOR__LOGINPASSWORD);
        String fullText = passwordContainer.getText();
        String password = fullText.split("\\r?\\n")[1].trim();
        return password;
    }
}