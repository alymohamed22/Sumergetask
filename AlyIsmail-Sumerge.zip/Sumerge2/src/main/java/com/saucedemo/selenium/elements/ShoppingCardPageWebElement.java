package com.saucedemo.selenium.elements;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShoppingCardPageWebElement {
    private static final By SELECTOR__CART_ITEMS_LIST
        = By.className("cart_list");
    private static final By SELECTOR__CART_ITEM
        = By.className("cart_item");
    private static final By SELECTOR__ITEM_NAME
        = By.className("inventory_item_name");
    private static final By SELECTOR__ITEM_PRICE
        = By.className("inventory_item_price");
    private static final By SELECTOR__ITEM_REMOVE_BUTTON
        = By.className("cart_button");
    private static final By SELECTOR__CONTINUE_SHOPPING_BUTTON
        = By.id("continue-shopping");
    private static final By SELECTOR__CHECKOUT_BUTTON = By.id("checkout");

    private final WebDriver driver;
    private final WebElement cartPageElement;

    public ShoppingCardPageWebElement(WebDriver driver) {
        this.driver = driver;
        WebElement tempElement = null;
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            tempElement = wait.until(ExpectedConditions
                .visibilityOfElementLocated(SELECTOR__CART_ITEMS_LIST));
        } catch (Exception e) {
            System.out.println("Cart page element not found: " + e.getMessage());
        }
        this.cartPageElement = tempElement;
    }

    public List<String> getCartItemNames() {
        return getCartAttribute(SELECTOR__ITEM_NAME);
    }

    public List<String> getCartItemPrices() {
        return getCartAttribute(SELECTOR__ITEM_PRICE);
    }

    public String getCartItemName(int itemIndex) {
        return getCartItemWebElement(itemIndex)
            .findElement(SELECTOR__ITEM_NAME).getText();
    }

    public String getCartItemPrice(int itemIndex) {
        return getCartItemWebElement(itemIndex)
            .findElement(SELECTOR__ITEM_PRICE).getText();
    }

    public void removeCartItem(int itemIndex) {
        WebElement cartItem = getCartItemWebElement(itemIndex);
        cartItem.findElement(SELECTOR__ITEM_REMOVE_BUTTON).click();
    }

    public int countCartItems() {
        return getCartItemsWebElement().size();
    }

    public void proceedToCheckout() {
        driver.findElement(SELECTOR__CHECKOUT_BUTTON).click();
    }

    public ProductsPageWebElement continueShopping() {
        driver.findElement(SELECTOR__CONTINUE_SHOPPING_BUTTON).click();
        return new ProductsPageWebElement(driver);
    }

    private List<WebElement> getCartItemsWebElement() {
        return driver.findElements(SELECTOR__CART_ITEM);
    }

    private WebElement getCartItemWebElement(int itemIndex) {
        List<WebElement> cartItems = getCartItemsWebElement();
        if (itemIndex >= 0 && itemIndex < cartItems.size()) {
            return cartItems.get(itemIndex);
        } else {
            throw new IndexOutOfBoundsException("Invalid cart item index: "
                                                + itemIndex);
        }
    }

    private List<String> getCartAttribute(By attributeSelector) {
        List<WebElement> cartItems = getCartItemsWebElement();
        List<String> attributeValues = new ArrayList<String>();
        for (WebElement item : cartItems) {
            attributeValues.add(item.findElement(attributeSelector).getText());
        }
        return attributeValues;
    }
}
